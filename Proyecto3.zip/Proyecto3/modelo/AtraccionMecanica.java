package parque.modelo;

import java.util.List;

public class AtraccionMecanica extends ElementoParque {
    private double alturaMinima;
    private double alturaMaxima;
    private double pesoMinimo;
    private double pesoMaximo;
    private List<String> contraindicaciones;

    public AtraccionMecanica(String nombre, String ubicacion, int cupoMaximo, int empleadosMinimos,
                             double alturaMinima, double alturaMaxima, double pesoMinimo, double pesoMaximo,
                             List<String> contraindicaciones) {
        super(nombre, ubicacion, cupoMaximo, empleadosMinimos);
        this.alturaMinima = alturaMinima;
        this.alturaMaxima = alturaMaxima;
        this.pesoMinimo = pesoMinimo;
        this.pesoMaximo = pesoMaximo;
        this.contraindicaciones = contraindicaciones;
    }

    @Override
    public boolean puedeAcceder(Cliente cliente) {
        if (cliente.getAltura() < alturaMinima || cliente.getAltura() > alturaMaxima) return false;
        if (cliente.getPeso() < pesoMinimo || cliente.getPeso() > pesoMaximo) return false;
        for (String condicion : cliente.getCondicionesMedicas()) {
            if (contraindicaciones.contains(condicion)) return false;
        }
        return true;
    }
}
