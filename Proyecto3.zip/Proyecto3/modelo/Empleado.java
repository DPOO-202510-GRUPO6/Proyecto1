package parque.modelo;

import java.io.Serializable;

public class Empleado implements Serializable {
    private String usuario;
    private String contrasena;
    private String nombre;
    private String rol;

    public Empleado(String usuario, String contrasena, String nombre, String rol) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.nombre = nombre;
        this.rol = rol;
    }

    public String getUsuario() { return usuario; }
    public String getContrasena() { return contrasena; }
    public String getNombre() { return nombre; }
    public String getRol() { return rol; }
}
