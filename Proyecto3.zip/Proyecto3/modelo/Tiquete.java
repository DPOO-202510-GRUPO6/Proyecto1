package parque.modelo;

import java.io.Serializable;

public class Tiquete implements Serializable {
    private String id;
    private String clienteNombre;
    private String tipo;
    private String atraccionNombre;
    private String fecha;

    public Tiquete(String id, String clienteNombre, String tipo, String atraccionNombre, String fecha) {
        this.id = id;
        this.clienteNombre = clienteNombre;
        this.tipo = tipo;
        this.atraccionNombre = atraccionNombre;
        this.fecha = fecha;
    }

    public String getId() { return id; }
    public String getClienteNombre() { return clienteNombre; }
    public String getTipo() { return tipo; }
    public String getAtraccionNombre() { return atraccionNombre; }
    public String getFecha() { return fecha; }
}
