package parque.modelo;

public class Espectaculo extends ElementoParque {
    public Espectaculo(String nombre, String ubicacion, int cupoMaximo, int empleadosMinimos) {
        super(nombre, ubicacion, cupoMaximo, empleadosMinimos);
    }

    @Override
    public boolean puedeAcceder(Cliente cliente) {
        return true;
    }
}
