package parque.service;

import parque.model.Empleado;
import java.util.*;

public class GestorEmpleados {
    private Map<String, Empleado> empleados = new HashMap<>();

    public void registrarEmpleado(Empleado e) {
        empleados.put(e.getId(), e);
    }

    public Empleado autenticar(String id, String contrasena) {
        Empleado e = empleados.get(id);
        if (e != null && e.getContrasena().equals(contrasena)) return e;
        return null;
    }

    public Collection<Empleado> listarEmpleados() {
        return empleados.values();
    }
}
