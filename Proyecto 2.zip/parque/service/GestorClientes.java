package parque.service;

import parque.model.Cliente;
import java.util.*;

public class GestorClientes {
    private Map<String, Cliente> clientes = new HashMap<>();

    public void registrarCliente(Cliente cliente) {
        clientes.put(cliente.getNombre(), cliente);
    }

    public Cliente buscarCliente(String nombre) {
        return clientes.get(nombre);
    }

    public Collection<Cliente> listarClientes() {
        return clientes.values();
    }
}
