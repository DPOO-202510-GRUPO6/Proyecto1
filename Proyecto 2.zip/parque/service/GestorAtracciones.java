package parque.service;

import parque.model.*;
import java.util.*;

public class GestorAtracciones {
    private List<ElementoParque> elementos = new ArrayList<>();

    public void registrarElemento(ElementoParque e) {
        elementos.add(e);
    }

    public List<ElementoParque> disponiblesParaCliente(Date hoy, boolean climaBueno, Cliente c) {
        List<ElementoParque> disponibles = new ArrayList<>();
        for (ElementoParque e : elementos) {
            if ((!e.requiereClima() || climaBueno) && e.puedeAcceder(c)) {
                disponibles.add(e);
            }
        }
        return disponibles;
    }

    public List<ElementoParque> listarElementos() {
        return elementos;
    }
}
