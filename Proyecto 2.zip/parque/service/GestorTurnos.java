package parque.service;

import parque.model.Turno;
import java.util.*;

public class GestorTurnos {
    private List<Turno> turnos = new ArrayList<>();

    public void asignarTurno(Turno t) {
        turnos.add(t);
    }

    public List<Turno> turnosPorFechaYAtraccion(String fecha, String atraccion) {
        List<Turno> res = new ArrayList<>();
        for (Turno t : turnos) {
            if (t.getFecha().equals(fecha) && t.getAtraccion().equalsIgnoreCase(atraccion)) {
                res.add(t);
            }
        }
        return res;
    }
}
