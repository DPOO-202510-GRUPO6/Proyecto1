package parque.service;

import parque.model.*;
import java.util.*;

public class GestorTiquetes {
    private Map<String, Tiquete> tiquetes = new HashMap<>();
    private List<FastPass> fastpasses = new ArrayList<>();

    public void registrarTiquete(Tiquete t) {
        tiquetes.put(t.getId(), t);
    }

    public Tiquete obtenerTiquete(String id) {
        return tiquetes.get(id);
    }

    public boolean usarTiquete(String id) {
        Tiquete t = tiquetes.get(id);
        if (t != null && !t.estaUsado()) {
            t.marcarUsado();
            return true;
        }
        return false;
    }

    public void registrarFastPass(FastPass fp) {
        fastpasses.add(fp);
    }

    public boolean usarFastPass(String idTiquete, Date fecha) {
        for (FastPass fp : fastpasses) {
            if (fp.getIdTiquete().equals(idTiquete) && !fp.estaUsado() && fp.getFechaValida().equals(fecha)) {
                fp.marcarUsado();
                return true;
            }
        }
        return false;
    }

    public Collection<Tiquete> listarTiquetes() {
        return tiquetes.values();
    }
}
