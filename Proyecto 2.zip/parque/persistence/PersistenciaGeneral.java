package parque.persistence;

import parque.model.*;
import parque.service.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class PersistenciaGeneral {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

    public static void cargarClientes(String ruta, GestorClientes gestor) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                if (p.length < 5) continue;
                List<String> condiciones = p[4].isEmpty() ? new ArrayList<>() : List.of(p[4].split(","));
                Cliente c = new Cliente(p[0], Integer.parseInt(p[1]), Double.parseDouble(p[2]), Double.parseDouble(p[3]), condiciones);
                gestor.registrarCliente(c);
            }
        }
    }

    public static void cargarEmpleados(String ruta, GestorEmpleados gestor) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                Empleado e = new Empleado(p[0], p[1], p[2], p[3]);
                gestor.registrarEmpleado(e);
            }
        }
    }

    public static void cargarTiquetes(String ruta, GestorTiquetes gestor) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                if (p[0].equals("IND")) {
                    Tiquete t = new TiqueteIndividual(p[1], p[2], sdf.parse(p[3]), p[4]);
                    gestor.registrarTiquete(t);
                } else {
                    Tiquete t = new TiqueteTemporada(p[1], p[2], sdf.parse(p[3]), p[4]);
                    gestor.registrarTiquete(t);
                }
            }
        }
    }

    public static void cargarFastPass(String ruta, GestorTiquetes gestor) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] p = linea.split(";");
                FastPass fp = new FastPass(p[0], sdf.parse(p[1]));
                gestor.registrarFastPass(fp);
            }
        }
    }
}
