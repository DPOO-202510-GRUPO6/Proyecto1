package parque.model;

import java.util.Date;

public class TiqueteTemporada extends Tiquete {
    private String tipoTemporada;

    public TiqueteTemporada(String id, String clienteNombre, Date fecha, String tipoTemporada) {
        super(id, clienteNombre, fecha);
        this.tipoTemporada = tipoTemporada;
    }

    public String getTipoTemporada() { return tipoTemporada; }

    @Override
    public String getTipo() {
        return "TEMPORADA";
    }
}
