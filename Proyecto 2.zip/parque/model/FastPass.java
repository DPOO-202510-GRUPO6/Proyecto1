package parque.model;

import java.util.Date;

public class FastPass {
    private String idTiquete;
    private Date fechaValida;
    private boolean usado;

    public FastPass(String idTiquete, Date fechaValida) {
        this.idTiquete = idTiquete;
        this.fechaValida = fechaValida;
        this.usado = false;
    }

    public String getIdTiquete() { return idTiquete; }
    public Date getFechaValida() { return fechaValida; }
    public boolean estaUsado() { return usado; }
    public void marcarUsado() { this.usado = true; }
}
