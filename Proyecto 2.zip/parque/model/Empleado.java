package parque.model;

public class Empleado {
    private String id;
    private String nombre;
    private String rol;
    private String contrasena;

    public Empleado(String id, String nombre, String rol, String contrasena) {
        this.id = id;
        this.nombre = nombre;
        this.rol = rol;
        this.contrasena = contrasena;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getRol() { return rol; }
    public String getContrasena() { return contrasena; }
}
