package parque.model;

public class Espectaculo extends ElementoParque {
    private String horario;

    public Espectaculo(String nombre, String ubicacion, int cupoMaximo, int empleadosMinimos,
                       boolean requiereClima, boolean esTemporada, String horario) {
        super(nombre, ubicacion, cupoMaximo, empleadosMinimos, requiereClima, esTemporada);
        this.horario = horario;
    }

    @Override
    public boolean puedeAcceder(Cliente cliente) {
        return true;
    }

    public String getHorario() {
        return horario;
    }
}
