package parque.model;

import java.util.List;

public class Cliente {
    private String nombre;
    private int edad;
    private double altura;
    private double peso;
    private List<String> condicionesMedicas;

    public Cliente(String nombre, int edad, double altura, double peso, List<String> condicionesMedicas) {
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
        this.peso = peso;
        this.condicionesMedicas = condicionesMedicas;
    }

    public String getNombre() { return nombre; }
    public int getEdad() { return edad; }
    public double getAltura() { return altura; }
    public double getPeso() { return peso; }
    public List<String> getCondicionesMedicas() { return condicionesMedicas; }
}
