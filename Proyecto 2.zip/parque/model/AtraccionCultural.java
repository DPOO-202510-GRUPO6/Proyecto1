package parque.model;

public class AtraccionCultural extends ElementoParque {
    private int edadMinima;

    public AtraccionCultural(String nombre, String ubicacion, int cupoMaximo, int empleadosMinimos,
                             boolean requiereClima, boolean esTemporada, int edadMinima) {
        super(nombre, ubicacion, cupoMaximo, empleadosMinimos, requiereClima, esTemporada);
        this.edadMinima = edadMinima;
    }

    @Override
    public boolean puedeAcceder(Cliente cliente) {
        return cliente.getEdad() >= edadMinima;
    }
}
