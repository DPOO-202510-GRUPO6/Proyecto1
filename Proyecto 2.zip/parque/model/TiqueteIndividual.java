package parque.model;

import java.util.Date;

public class TiqueteIndividual extends Tiquete {
    private String atraccion;

    public TiqueteIndividual(String id, String clienteNombre, Date fecha, String atraccion) {
        super(id, clienteNombre, fecha);
        this.atraccion = atraccion;
    }

    public String getAtraccion() { return atraccion; }

    @Override
    public String getTipo() {
        return "INDIVIDUAL";
    }
}
