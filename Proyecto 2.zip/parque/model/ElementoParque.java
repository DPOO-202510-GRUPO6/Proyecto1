package parque.model;

import java.io.Serializable;

public abstract class ElementoParque implements Serializable {
    protected String nombre;
    protected String ubicacion;
    protected int cupoMaximo;
    protected int empleadosMinimos;
    protected boolean requiereClima;
    protected boolean esTemporada;

    public ElementoParque(String nombre, String ubicacion, int cupoMaximo, int empleadosMinimos,
                          boolean requiereClima, boolean esTemporada) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.cupoMaximo = cupoMaximo;
        this.empleadosMinimos = empleadosMinimos;
        this.requiereClima = requiereClima;
        this.esTemporada = esTemporada;
    }

    public String getNombre() { return nombre; }
    public String getUbicacion() { return ubicacion; }
    public int getCupoMaximo() { return cupoMaximo; }
    public int getEmpleadosMinimos() { return empleadosMinimos; }
    public boolean requiereClima() { return requiereClima; }
    public boolean esTemporada() { return esTemporada; }

    public abstract boolean puedeAcceder(Cliente cliente);
}
