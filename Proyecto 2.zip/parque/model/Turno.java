package parque.model;

public class Turno {
    private String fecha; // formato yyyy-MM-dd
    private String atraccion;
    private String empleadoId;

    public Turno(String fecha, String atraccion, String empleadoId) {
        this.fecha = fecha;
        this.atraccion = atraccion;
        this.empleadoId = empleadoId;
    }

    public String getFecha() { return fecha; }
    public String getAtraccion() { return atraccion; }
    public String getEmpleadoId() { return empleadoId; }
}
