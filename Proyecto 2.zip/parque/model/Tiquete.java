package parque.model;

import java.util.Date;

public abstract class Tiquete {
    protected String id;
    protected String clienteNombre;
    protected Date fecha;
    protected boolean usado;

    public Tiquete(String id, String clienteNombre, Date fecha) {
        this.id = id;
        this.clienteNombre = clienteNombre;
        this.fecha = fecha;
        this.usado = false;
    }

    public String getId() { return id; }
    public String getClienteNombre() { return clienteNombre; }
    public Date getFecha() { return fecha; }
    public boolean estaUsado() { return usado; }
    public void marcarUsado() { this.usado = true; }

    public abstract String getTipo();
}
