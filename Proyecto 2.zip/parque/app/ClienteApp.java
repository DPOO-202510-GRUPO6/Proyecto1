package parque.app;

import parque.model.*;
import parque.service.*;
import parque.persistence.PersistenciaGeneral;

import java.util.*;
import java.text.SimpleDateFormat;

public class ClienteApp {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        GestorClientes gestorClientes = new GestorClientes();
        GestorTiquetes gestorTiquetes = new GestorTiquetes();

        PersistenciaGeneral.cargarClientes("parque/datos/clientes.txt", gestorClientes);
        PersistenciaGeneral.cargarTiquetes("parque/datos/tiquetes.txt", gestorTiquetes);
        PersistenciaGeneral.cargarFastPass("parque/datos/fastpass.txt", gestorTiquetes);

        System.out.println("🎫 Bienvenido al sistema de clientes del Parque");
        System.out.print("Ingrese su nombre: ");
        String nombre = sc.nextLine();
        Cliente c = gestorClientes.buscarCliente(nombre);

        if (c == null) {
            System.out.println("❌ Cliente no registrado.");
            return;
        }

        System.out.print("Ingrese el ID de su tiquete: ");
        String id = sc.nextLine();

        if (gestorTiquetes.usarTiquete(id)) {
            System.out.println("✅ Acceso permitido. Disfrute su visita!");
        } else {
            System.out.println("❌ Tiquete inválido o ya utilizado.");
        }

        Date hoy = sdf.parse("2025-05-20");
        if (gestorTiquetes.usarFastPass(id, hoy)) {
            System.out.println("⚡ FastPass activado para hoy.");
        } else {
            System.out.println("⚡ No tiene FastPass o ya fue usado.");
        }
    }
}
