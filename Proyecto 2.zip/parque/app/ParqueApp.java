package parque.app;

import parque.model.*;
import parque.service.*;
import parque.persistence.PersistenciaGeneral;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ParqueApp {
    public static void main(String[] args) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date hoy = sdf.parse("2025-05-20");

        GestorClientes gestorClientes = new GestorClientes();
        GestorEmpleados gestorEmpleados = new GestorEmpleados();
        GestorTiquetes gestorTiquetes = new GestorTiquetes();
        GestorTurnos gestorTurnos = new GestorTurnos();

        // Cargar desde archivos
        PersistenciaGeneral.cargarClientes("parque/datos/clientes.txt", gestorClientes);
        PersistenciaGeneral.cargarEmpleados("parque/datos/empleados.txt", gestorEmpleados);
        PersistenciaGeneral.cargarTiquetes("parque/datos/tiquetes.txt", gestorTiquetes);
        PersistenciaGeneral.cargarFastPass("parque/datos/fastpass.txt", gestorTiquetes);

        // Probar uso de tiquete
        System.out.println("\n🎟️ Uso de tiquete T001:");
        if (gestorTiquetes.usarTiquete("T001")) {
            System.out.println("✅ Tiquete válido.");
        } else {
            System.out.println("❌ Tiquete ya fue usado o no existe.");
        }

        // Probar reutilización
        System.out.println("\n🔁 Reutilización de T001:");
        if (gestorTiquetes.usarTiquete("T001")) {
            System.out.println("❌ ERROR: permitió reuso.");
        } else {
            System.out.println("✅ Correctamente bloqueado.");
        }

        // Validar FastPass
        System.out.println("\n⚡ Validar FastPass para T001:");
        if (gestorTiquetes.usarFastPass("T001", hoy)) {
            System.out.println("✅ FastPass válido.");
        } else {
            System.out.println("❌ FastPass inválido.");
        }

        // Login empleado
        System.out.println("\n🔐 Login empleado EMP001:");
        Empleado e = gestorEmpleados.autenticar("EMP001", "1234");
        if (e != null) {
            System.out.println("✅ Bienvenido " + e.getNombre() + " [" + e.getRol() + "]");
        } else {
            System.out.println("❌ Acceso denegado.");
        }
    }
}
