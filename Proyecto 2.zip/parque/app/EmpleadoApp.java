package parque.app;

import parque.model.*;
import parque.service.*;
import parque.persistence.PersistenciaGeneral;

import java.util.*;

public class EmpleadoApp {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        GestorEmpleados gestorEmpleados = new GestorEmpleados();
        PersistenciaGeneral.cargarEmpleados("parque/datos/empleados.txt", gestorEmpleados);

        System.out.println("🛠 Sistema de empleados del Parque");
        System.out.print("Ingrese su ID: ");
        String id = sc.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String pass = sc.nextLine();

        Empleado e = gestorEmpleados.autenticar(id, pass);
        if (e == null) {
            System.out.println("❌ Autenticación fallida.");
            return;
        }

        System.out.println("✅ Bienvenido " + e.getNombre() + " [" + e.getRol() + "]");
        // Aquí se pueden agregar más opciones (validar tiquete, ver turnos, etc.)
    }
}
