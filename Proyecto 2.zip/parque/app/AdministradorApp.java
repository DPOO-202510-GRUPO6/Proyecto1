package parque.app;

import parque.model.*;
import parque.service.*;
import parque.persistence.PersistenciaGeneral;

import java.util.*;

public class AdministradorApp {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        GestorEmpleados gestorEmpleados = new GestorEmpleados();
        PersistenciaGeneral.cargarEmpleados("parque/datos/empleados.txt", gestorEmpleados);

        System.out.println("🔒 Sistema de administración del Parque");
        System.out.print("Ingrese su ID: ");
        String id = sc.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String pass = sc.nextLine();

        Empleado admin = gestorEmpleados.autenticar(id, pass);
        if (admin == null || !admin.getRol().equalsIgnoreCase("ADMIN")) {
            System.out.println("❌ Acceso restringido.");
            return;
        }

        System.out.println("✅ Acceso administrativo concedido. Bienvenido " + admin.getNombre());

        // Aquí se pueden agregar opciones para registrar empleados, espectáculos, atracciones, etc.
    }
}
