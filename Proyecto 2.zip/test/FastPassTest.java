package test;

import static org.junit.Assert.*;
import org.junit.Test;
import parque.model.FastPass;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FastPassTest {

    @Test
    public void testUsarFastPass() throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date hoy = sdf.parse("2025-05-20");

        FastPass fp = new FastPass("T1", hoy);
        assertFalse(fp.estaUsado());
        assertEquals(hoy, fp.getFechaValida());

        fp.marcarUsado();
        assertTrue(fp.estaUsado());
    }
}
