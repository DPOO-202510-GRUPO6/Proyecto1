package test;

import static org.junit.Assert.*;
import org.junit.Test;
import parque.model.Cliente;
import parque.service.GestorClientes;
import java.util.List;

public class GestorClientesTest {

    @Test
    public void testRegistroYBusquedaCliente() {
        GestorClientes gestor = new GestorClientes();
        Cliente c = new Cliente("Carla", 22, 1.60, 55.0, List.of("asma"));
        gestor.registrarCliente(c);

        Cliente encontrado = gestor.buscarCliente("Carla");
        assertNotNull(encontrado);
        assertEquals(22, encontrado.getEdad());
        assertEquals("asma", encontrado.getCondicionesMedicas().get(0));
    }

    @Test
    public void testBusquedaClienteInexistente() {
        GestorClientes gestor = new GestorClientes();
        assertNull(gestor.buscarCliente("Fantasma"));
    }
}
