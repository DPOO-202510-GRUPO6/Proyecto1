package test;

import static org.junit.Assert.*;
import org.junit.Test;
import parque.model.*;
import java.util.Date;

public class TiqueteTest {

    @Test
    public void testUsarTiquete() {
        Tiquete t = new TiqueteIndividual("T1", "Ana", new Date(), "Montaña Rusa");
        assertFalse(t.estaUsado());
        t.marcarUsado();
        assertTrue(t.estaUsado());
    }

    @Test
    public void testTipoTiquete() {
        Tiquete t1 = new TiqueteIndividual("T2", "Luis", new Date(), "Casa del Terror");
        Tiquete t2 = new TiqueteTemporada("T3", "Marta", new Date(), "anual");

        assertEquals("INDIVIDUAL", t1.getTipo());
        assertEquals("TEMPORADA", t2.getTipo());
    }
}
