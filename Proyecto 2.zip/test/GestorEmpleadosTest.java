package test;

import static org.junit.Assert.*;
import org.junit.Test;
import parque.model.Empleado;
import parque.service.GestorEmpleados;

public class GestorEmpleadosTest {

    @Test
    public void testAutenticacionCorrecta() {
        GestorEmpleados gestor = new GestorEmpleados();
        Empleado emp = new Empleado("E1", "Pedro", "OPERADOR", "abc123");
        gestor.registrarEmpleado(emp);

        Empleado autenticado = gestor.autenticar("E1", "abc123");
        assertNotNull(autenticado);
        assertEquals("Pedro", autenticado.getNombre());
    }

    @Test
    public void testAutenticacionFallida() {
        GestorEmpleados gestor = new GestorEmpleados();
        Empleado emp = new Empleado("E2", "Laura", "ADMIN", "adminpass");
        gestor.registrarEmpleado(emp);

        Empleado fail = gestor.autenticar("E2", "wrongpass");
        assertNull(fail);
    }
}
