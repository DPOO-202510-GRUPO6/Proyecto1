# Historias de Usuario - Parque de Atracciones

## 🎫 Cliente

**HU-C1: Validar acceso con tiquete individual**  
Como cliente del parque, quiero ingresar mi nombre y el código de mi tiquete para validar si tengo acceso, de modo que pueda entrar al parque de forma correcta.

**HU-C2: Activar FastPass si está disponible**  
Como cliente, quiero que el sistema me diga si tengo un FastPass activo para hoy, para saber si puedo saltarme la fila.

---

## 🛠 Empleado

**HU-E1: Autenticación de empleado**  
Como empleado, quiero ingresar mi ID y contraseña, para acceder a mis funcionalidades de validación de acceso y turnos.

**HU-E2: Visualizar mis turnos asignados**  
Como empleado, quiero ver los turnos asignados por día y atracción, para saber en qué momento debo cumplir con mi labor.

---

## 🔐 Administrador

**HU-A1: Autenticación de administrador**  
Como administrador, quiero ingresar mis credenciales, para gestionar el sistema del parque.

**HU-A2: Gestionar empleados**  
Como administrador, quiero registrar y actualizar los datos de los empleados para mantener el sistema actualizado.

**HU-A3: Registrar atracciones y espectáculos**  
Como administrador, quiero agregar y modificar atracciones y espectáculos, para mantener el parque actualizado.

