# 📐 Documento de Diseño - Parque de Atracciones

## 1. Estructura General del Sistema

El sistema está dividido en los siguientes paquetes:

- `model`: Contiene las clases que representan el dominio (Cliente, Empleado, Tiquete, FastPass, Atracción, etc.)
- `service`: Implementa la lógica de negocio a través de gestores (`GestorClientes`, `GestorTiquetes`, etc.)
- `persistence`: Se encarga de la lectura/escritura de archivos de datos `.txt`.
- `app`: Interfaces de consola para cada tipo de usuario (`ClienteApp`, `EmpleadoApp`, `AdministradorApp`)
- `test`: Pruebas unitarias en JUnit.

## 2. Separación de Lógica e Interfaz

Cada interfaz de consola (`ClienteApp`, `EmpleadoApp`, `AdministradorApp`) accede exclusivamente a los gestores del paquete `service`, sin implementar lógica directamente.  
Esto garantiza una buena separación entre presentación y lógica de negocio.

## 3. Persistencia

El sistema utiliza archivos `.txt` para guardar y cargar:

- Clientes (`clientes.txt`)
- Empleados (`empleados.txt`)
- Tiquetes y FastPass (`tiquetes.txt`, `fastpass.txt`)

Los datos se cargan automáticamente al iniciar cada `App`.

## 4. Validaciones

La lógica del sistema valida:

- Restricciones físicas (altura, peso, salud)
- Restricciones de uso único de tiquetes y FastPass
- Autenticación por credenciales y rol
- Validación de disponibilidad por fecha y clima

## 5. Diagramas de Clases (Resumen)

> ⚠️ Este es un resumen textual. Se recomienda visualizar el diagrama UML completo entregado aparte en `png/pdf`.

**Modelo General:**

- `Cliente`, `Empleado`, `Turno`
- `Tiquete` (abstracta) → `TiqueteIndividual`, `TiqueteTemporada`
- `ElementoParque` (abstracta) → `AtraccionMecanica`, `AtraccionCultural`, `Espectaculo`
- `FastPass` (asociado a un `Tiquete`)

**Gestores:**

- `GestorClientes`
- `GestorEmpleados`
- `GestorTiquetes`
- `GestorTurnos`
- `GestorAtracciones`

**Relaciones destacadas:**
- `Empleado` puede ser autenticado por `GestorEmpleados`
- `Tiquete` es gestionado por `GestorTiquetes` que permite uso, registro y validación
- `FastPass` se usa junto con el `Tiquete` correspondiente

## 6. Pruebas

Todas las pruebas se encuentran en el paquete `test/`:

- `TiqueteTest`, `FastPassTest`
- `GestorEmpleadosTest`, `GestorClientesTest`

Cada prueba cubre los casos más relevantes definidos en las historias de usuario.

